import json
a={"name": "David","class":"I","age": 6}
b=json.dumps(a)
print(type(b))
print(b)