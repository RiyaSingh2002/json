import json
a={
    '4': 5, 
    '6': 7, 
    '1': 3, 
    '2': 4}
v=json.dumps(a)
print(type(v))
print(v)    