import json
file_name="mjson7.txt"
d={}
a=open("mjson7.txt")


