import json
a=["neelam","programer","24","2400"]
b=["komal","trainer","24","20000"]
c=["anuradha","HR","25","40000"]
d=["Abhishek","manager","29","63000"]  
e=["name","designation","age","salary"]
dict1={}
dict2={}
dict3={}
dict4={}
dict5={}
i=0
while i<len(a):
    dict1[b[i]]=a[i]
    dict2[b[i]]=b[i]
    dict3[b[i]]=c[i]
    dict4[b[i]]=d[i]
    dict5[b[i]]=e[i]
    i=i+1
    dict5["emply1"]=dict1
    dict5["emply2"]=dict2
    dict5["emply3"]=dict3
    dict5["emply4"]=dict4
    dict5["emply5"]=dict5


    
print(dict5)
k=json.dumps(dict5)
print(type(k))
print(k)
