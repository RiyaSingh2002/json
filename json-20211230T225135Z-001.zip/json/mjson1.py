import json
a='{"Name":"Ram","Class":"IV","Age":9 }'
b=json.loads(a)
print(type(b))
print(b)